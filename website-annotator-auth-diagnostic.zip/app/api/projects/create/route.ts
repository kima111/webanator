import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supa = await createClient();

  const { data: { user }, error: authErr } = await supa.auth.getUser();
  if (authErr) return NextResponse.json({ error: `auth.getUser: ${authErr.message}` }, { status: 400 });
  if (!user)  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { name, url, seedAnnotations } = await req.json();

  // 1) Insert project (uses owner_id — make sure your DB column is owner_id)
  const { data: project, error: pErr } = await supa
    .from("projects")
    .insert({ name: name ?? "Untitled", owner_id: user.id })
    .select()
    .single();
  if (pErr || !project) {
    return NextResponse.json({ error: `projects insert: ${pErr?.message ?? "unknown"}` }, { status: 400 });
  }

  // 2) Add creator as a member (role owner)
  const { error: mErr } = await supa.from("project_members").insert({
    project_id: project.id,
    user_id: user.id,
    role: "owner",
  });
  if (mErr) {
    return NextResponse.json({ error: `project_members insert: ${mErr.message}` }, { status: 400 });
  }

  // 3) Optional seed annotation
  if (seedAnnotations && url) {
    const { error: aErr } = await supa.from("annotations").insert({
      project_id: project.id,
      created_by: user.id,
      url,
      selector: { type: "page", value: "document" },
      body: { text: "Welcome annotation" },
    });
    if (aErr) {
      return NextResponse.json({ error: `annotations insert: ${aErr.message}` }, { status: 400 });
    }
  }

  return NextResponse.json({ projectId: project.id }, { status: 201 });
}
