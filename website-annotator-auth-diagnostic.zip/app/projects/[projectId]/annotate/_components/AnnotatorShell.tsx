"use client";
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAnnotationRealtime, useMessagesRealtime } from "@/lib/hooks/realtime";
import AnnotationList from "./AnnotationList";
import MessagePanel from "./MessagePanel";
import IframeOverlay from "./IframeOverlay";

export default function AnnotatorShell({ projectId, initialUrl }: { projectId: string; initialUrl: string }) {
  const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(null);
  const [pageUrl, setPageUrl] = useState<string>(initialUrl || "");
  const [tempUrl, setTempUrl] = useState<string>(initialUrl || "https://example.com");

  const { annotations } = useAnnotationRealtime(projectId, pageUrl);
  const { messages, sendMessage, subscribeTo } = useMessagesRealtime();

  useEffect(() => {
    if (activeAnnotationId) subscribeTo(activeAnnotationId);
  }, [activeAnnotationId, subscribeTo]);

  return (
    <div className="grid grid-cols-12 gap-4 h-[calc(100vh-88px)]">
      {/* Left: website + URL bar */}
      <div className="col-span-8 h-full">
        <Card className="h-full">
          <CardContent className="p-0 h-full">
            <div className="p-3 border-b flex gap-2 items-center">
              <Input
                value={tempUrl}
                onChange={(e) => setTempUrl(e.target.value)}
                placeholder="Enter a URL to annotate"
              />
              <Button onClick={() => setPageUrl(tempUrl)}>Load</Button>
            </div>
            <div className="h-[calc(100%-56px)]">
              <IframeOverlay url={pageUrl} annotations={annotations} onSelect={setActiveAnnotationId} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Middle: annotation list */}
      <div className="col-span-4 h-full">
        <Card className="h-full">
          <CardContent className="p-0 h-full">
            <div className="p-3 border-b font-semibold">Annotations</div>
            <AnnotationList items={annotations} activeId={activeAnnotationId} onSelect={setActiveAnnotationId} />
          </CardContent>
        </Card>
      </div>

      {/* Right: messages */}
      <div className="fixed right-4 top-[88px] bottom-4 w-[360px]">
        <Card className="h-full">
          <CardContent className="p-0 h-full">
            <MessagePanel annotationId={activeAnnotationId} messages={messages} onSend={sendMessage} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}