"use client";
import { useRef, useEffect } from "react";
import type { Annotation } from "@/lib/types/annotations";

type IframeMessage = { type?: "ANNOTATION_CLICK"; id?: string };

export default function IframeOverlay({
  url,
  annotations,
  onSelect,
}: {
  url: string;
  annotations: Annotation[];
  onSelect: (id: Annotation["id"]) => void;
}) {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      const data = e.data as IframeMessage;
      if (data?.type === "ANNOTATION_CLICK" && data.id) onSelect(data.id);
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [onSelect]);

  return (
    <div className="relative h-full w-full">
      <iframe ref={iframeRef} src={url || "about:blank"} className="w-full h-full border-0" />
      <div className="pointer-events-none absolute inset-0">
        {annotations.map((a, i) => (
          <div
            key={a.id}
            className="absolute bg-red-500 rounded-full w-3 h-3"
            style={{ top: 20 + i * 20, left: 20 }}
            onClick={() => onSelect(a.id)}
          />
        ))}
      </div>
    </div>
  );
}
