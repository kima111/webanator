// app/projects/[projectId]/annotate/page.tsx
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import AnnotatorShell from "./_components/AnnotatorShell";

type Params = { projectId: string };
type Search = { url?: string };

export default async function AnnotatePage(
  props: { params: Promise<Params>; searchParams?: Promise<Search> }
) {
  const params = await props.params;
  const search = props.searchParams ? await props.searchParams : undefined;

  const projectId = params.projectId;
  const url = search?.url ?? "";

  const supa = await createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return redirect("/login");

  const { data: member } = await supa
    .from("project_members")
    .select("project_id")
    .eq("project_id", projectId)
    .eq("user_id", user.id)
    .maybeSingle();

  if (!member) return redirect("/404");

  return <AnnotatorShell projectId={projectId} initialUrl={url} />;
}
