"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ProjectsPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [url, setUrl] = useState("https://example.com");
  const [loading, setLoading] = useState(false);

  async function handleCreate() {
    setLoading(true);
    try {
      const res = await fetch("/api/projects/create", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ name: name || "My Project", url, seedAnnotations: true }),
      });
      if (!res.ok) {
  let details = "";
  try { details = JSON.stringify(await res.json()); } catch {}
  console.error("Create project failed:", res.status, details);
  throw new Error(details || `Failed to create project (${res.status})`);
}
      const data = (await res.json()) as { projectId: string };
      router.push(`/projects/${data.projectId}/annotate?url=${encodeURIComponent(url)}`);
    } catch (e) {
      console.error(e);
      alert("Create failed. Check console.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-4">
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="text-lg font-semibold">Create a project</div>
          <Input placeholder="Project name" value={name} onChange={(e) => setName(e.target.value)} />
          <Input placeholder="Start URL (page to annotate)" value={url} onChange={(e) => setUrl(e.target.value)} />
          <Button onClick={handleCreate} disabled={loading} className="w-full">
            {loading ? "Creating…" : "Create & Start Annotating"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}