Here’s the **ready-to-drop code** mapped to your `website-annotator-auth` tree. Copy these into the indicated paths.

---

## 1. Database (`/db/migrations.sql`)

```sql
-- Add annotations + messages tables
create table if not exists public.annotations (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete set null,
  url text not null,
  selector jsonb not null,
  body jsonb not null default '{}'::jsonb,
  status text not null default 'open' check (status in ('open','resolved','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.annotation_messages (
  id uuid primary key default gen_random_uuid(),
  annotation_id uuid not null references public.annotations(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.annotations enable row level security;
alter table public.annotation_messages enable row level security;
```

---

## 2. API routes

### `/app/api/projects/create/route.ts`

```ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { name, url, seedAnnotations } = await req.json();

  const { data: project, error } = await supa
    .from("projects")
    .insert({ name, owner_id: user.id })
    .select()
    .single();

  if (error || !project) return NextResponse.json({ error: error?.message }, { status: 400 });

  await supa.from("project_members").insert({
    project_id: project.id,
    user_id: user.id,
    role: "owner",
  });

  if (seedAnnotations && url) {
    await supa.from("annotations").insert({
      project_id: project.id,
      created_by: user.id,
      url,
      selector: { type: "page", value: "document" },
      body: { text: "Welcome annotation" },
    });
  }

  return NextResponse.json({ projectId: project.id }, { status: 201 });
}
```

### `/app/api/annotations/route.ts`

```ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  const pageUrl = url.searchParams.get("url");

  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let query = supa.from("annotations").select("*").eq("project_id", projectId);
  if (pageUrl) query = query.eq("url", pageUrl);
  const { data, error } = await query.order("created_at", { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ annotations: data });
}

export async function POST(req: Request) {
  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { project_id, url, selector, body } = await req.json();
  const { data, error } = await supa
    .from("annotations")
    .insert({ project_id, created_by: user.id, url, selector, body })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ annotation: data }, { status: 201 });
}
```

### `/app/api/annotations/[id]/messages/route.ts`

```ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data, error } = await supa
    .from("annotation_messages")
    .select("*")
    .eq("annotation_id", params.id)
    .order("created_at");

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ messages: data });
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { body } = await req.json();
  const { data, error } = await supa
    .from("annotation_messages")
    .insert({ annotation_id: params.id, author_id: user.id, body })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ message: data }, { status: 201 });
}
```

---

## 3. Project Annotate route

### `/app/projects/[projectId]/annotate/page.tsx`

```tsx
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import AnnotatorShell from "./_components/AnnotatorShell";

export default async function AnnotatePage({ params, searchParams }: any) {
  const supa = createClient();
  const {
    data: { user },
  } = await supa.auth.getUser();
  if (!user) return redirect("/login");

  const { data: member } = await supa
    .from("project_members")
    .select("project_id")
    .eq("project_id", params.projectId)
    .eq("user_id", user.id)
    .maybeSingle();

  if (!member) return redirect("/404");

  return <AnnotatorShell projectId={params.projectId} initialUrl={searchParams?.url ?? ""} />;
}
```

### `/app/projects/[projectId]/annotate/_components/AnnotatorShell.tsx`

```tsx
"use client";
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAnnotationRealtime, useMessagesRealtime } from "@/lib/hooks/realtime";
import AnnotationList from "./AnnotationList";
import MessagePanel from "./MessagePanel";

export default function AnnotatorShell({ projectId, initialUrl }: { projectId: string; initialUrl: string }) {
  const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(null);
  const { annotations, createAnnotation } = useAnnotationRealtime(projectId, initialUrl);
  const { messages, sendMessage, subscribeTo } = useMessagesRealtime();

  useEffect(() => {
    if (activeAnnotationId) subscribeTo(activeAnnotationId);
  }, [activeAnnotationId, subscribeTo]);

  return (
    <div className="grid grid-cols-12 gap-4 h-[calc(100vh-88px)]">
      <div className="col-span-8">
        <Card className="h-full">
          <CardContent className="p-0 h-full">Website iframe goes here</CardContent>
        </Card>
      </div>
      <div className="col-span-4">
        <Card className="h-full">
          <CardContent className="p-0 h-full">
            <AnnotationList items={annotations} activeId={activeAnnotationId} onSelect={setActiveAnnotationId} />
          </CardContent>
        </Card>
      </div>
      <div className="fixed right-4 top-[88px] bottom-4 w-[360px]">
        <Card className="h-full">
          <CardContent className="p-0 h-full">
            <MessagePanel annotationId={activeAnnotationId} messages={messages} onSend={sendMessage} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
```

---

## 4. Hooks (`/lib/hooks/realtime.ts`)

```ts
"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export function useAnnotationRealtime(projectId: string, url?: string) {
  const supa = createClientComponentClient();
  const [annotations, setAnnotations] = useState<any[]>([]);

  const fetchAll = useCallback(async () => {
    const qs = new URLSearchParams({ projectId, ...(url ? { url } : {}) }).toString();
    const res = await fetch(`/api/annotations?${qs}`, { credentials: "include" });
    const data = await res.json();
    setAnnotations(data.annotations ?? []);
  }, [projectId, url]);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  return { annotations, createAnnotation: fetchAll };
}

export function useMessagesRealtime() {
  const [messages, setMessages] = useState<any[]>([]);

  const subscribeTo = useCallback(async (annotationId: string) => {
    const res = await fetch(`/api/annotations/${annotationId}/messages`, { credentials: "include" });
    const data = await res.json();
    setMessages(data.messages ?? []);
  }, []);

  const sendMessage = useCallback(async (annotationId: string, body: string) => {
    await fetch(`/api/annotations/${annotationId}/messages`, {
      method: "POST",
      credentials: "include",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ body }),
    });
  }, []);

  return { messages, sendMessage, subscribeTo };
}
```

---

This gives you the baseline: DB schema, API routes, project annotate page, shell, and hooks. Reuse your UI components (`card`, `button`, `input`) for `AnnotationList` and `MessagePanel` just like shown earlier.

Do you want me to also generate **`AnnotationList.tsx`** and **`MessagePanel.tsx`** in full with your ShadCN components wired in?
