-- Project members roles + acceptance + comments table and RLS
-- Run in Supabase SQL editor (Postgres) or psql connected to your project.

-- Ensure gen_random_uuid() is available
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) Columns (safe if they already exist)
ALTER TABLE public.project_members
  ADD COLUMN IF NOT EXISTS role text CHECK (role IN ('viewer','editor','owner')) DEFAULT 'viewer';

ALTER TABLE public.project_members
  ADD COLUMN IF NOT EXISTS joined_at timestamptz;

-- Ensure a sensible default and backfill any nulls
ALTER TABLE public.project_members ALTER COLUMN joined_at SET DEFAULT now();
UPDATE public.project_members SET joined_at = now() WHERE joined_at IS NULL;

-- 2) Helpful index
CREATE INDEX IF NOT EXISTS idx_project_members_project_user
  ON public.project_members(project_id, user_id);

-- 3) Enable RLS (if not already)
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_members ENABLE ROW LEVEL SECURITY;

-- Optional: comments table for annotations/discussions
CREATE TABLE IF NOT EXISTS public.project_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz
);

ALTER TABLE public.project_comments ENABLE ROW LEVEL SECURITY;

-- Helpful index for comment lookups per project
CREATE INDEX IF NOT EXISTS idx_project_comments_project
  ON public.project_comments(project_id);

-- Maintain updated_at automatically on updates
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS trg_project_comments_updated_at ON public.project_comments;

CREATE TRIGGER trg_project_comments_updated_at
BEFORE UPDATE ON public.project_comments
FOR EACH ROW
EXECUTE FUNCTION public.set_updated_at();

-- 4) Policies
-- View projects if you are a member
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'projects'
      AND policyname = 'projects_select_if_member'
  ) THEN
    CREATE POLICY "projects_select_if_member"
      ON public.projects FOR SELECT
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = projects.id
            AND pm.user_id = auth.uid()
        )
      );
  END IF;
END
$$;

-- Manage projects (owner-only update/delete)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'projects'
      AND policyname = 'projects_update_if_owner'
  ) THEN
    CREATE POLICY "projects_update_if_owner"
      ON public.projects FOR UPDATE
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = projects.id
            AND pm.user_id = auth.uid()
            AND pm.role = 'owner'
        )
      );
  END IF;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'projects'
      AND policyname = 'projects_delete_if_owner'
  ) THEN
    CREATE POLICY "projects_delete_if_owner"
      ON public.projects FOR DELETE
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = projects.id
            AND pm.user_id = auth.uid()
            AND pm.role = 'owner'
        )
      );
  END IF;
END
$$;

-- Replace any previous recursive project_members policies
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_select_if_in_project'
  ) THEN
    DROP POLICY "project_members_select_if_in_project" ON public.project_members;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_insert_if_owner'
  ) THEN
    DROP POLICY "project_members_insert_if_owner" ON public.project_members;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_update_if_owner'
  ) THEN
    DROP POLICY "project_members_update_if_owner" ON public.project_members;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_delete_if_owner'
  ) THEN
    DROP POLICY "project_members_delete_if_owner" ON public.project_members;
  END IF;
END
$$;

-- Minimal non-recursive project_members policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_select_own'
  ) THEN
    CREATE POLICY "project_members_select_own"
      ON public.project_members FOR SELECT
      USING (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='project_members'
      AND policyname='project_members_insert_self'
  ) THEN
    CREATE POLICY "project_members_insert_self"
      ON public.project_members FOR INSERT
      WITH CHECK (user_id = auth.uid());
  END IF;
END
$$;

-- Comments policies
-- Read: any project member can read all comments for that project
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'project_comments'
      AND policyname = 'project_comments_select_if_member'
  ) THEN
    CREATE POLICY "project_comments_select_if_member"
      ON public.project_comments FOR SELECT
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
        )
      );
  END IF;
END
$$;

-- Insert: editor or owner can add comments, but only as themselves
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'project_comments'
      AND policyname = 'project_comments_insert_if_editor_or_owner'
  ) THEN
    ALTER POLICY "project_comments_insert_if_editor_or_owner"
      ON public.project_comments
      WITH CHECK (
        user_id = auth.uid()
        AND EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND pm.role IN ('editor','owner')
        )
      );
  ELSE
    CREATE POLICY "project_comments_insert_if_editor_or_owner"
      ON public.project_comments FOR INSERT
      WITH CHECK (
        user_id = auth.uid()
        AND EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND pm.role IN ('editor','owner')
        )
      );
  END IF;
END
$$;

-- Update: owner can edit any comment; editor can edit only their own.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'project_comments'
      AND policyname = 'project_comments_update_if_owner_or_self_editor'
  ) THEN
    ALTER POLICY "project_comments_update_if_owner_or_self_editor"
      ON public.project_comments
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND (pm.role = 'owner' OR (pm.role = 'editor' AND user_id = auth.uid()))
        )
      )
      WITH CHECK (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND (pm.role = 'owner' OR (pm.role = 'editor' AND user_id = auth.uid()))
        )
      );
  ELSE
    CREATE POLICY "project_comments_update_if_owner_or_self_editor"
      ON public.project_comments FOR UPDATE
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND (pm.role = 'owner' OR (pm.role = 'editor' AND user_id = auth.uid()))
        )
      )
      WITH CHECK (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND (pm.role = 'owner' OR (pm.role = 'editor' AND user_id = auth.uid()))
        )
      );
  END IF;
END
$$;

-- Delete: owner can delete any, editor can delete own
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'project_comments'
      AND policyname = 'project_comments_delete_if_owner_or_self_editor'
  ) THEN
    CREATE POLICY "project_comments_delete_if_owner_or_self_editor"
      ON public.project_comments FOR DELETE
      USING (
        EXISTS (
          SELECT 1
          FROM public.project_members pm
          WHERE pm.project_id = project_comments.project_id
            AND pm.user_id = auth.uid()
            AND (pm.role = 'owner' OR (pm.role = 'editor' AND user_id = auth.uid()))
        )
      );
  END IF;
END
$$;
