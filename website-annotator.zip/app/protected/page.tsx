import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { InfoIcon, Plus } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import MembersDialog from "@/components/members-dialog";
import { createAdminClient } from "@/lib/supabase/admin";
import { revalidatePath } from "next/cache";
import type { User } from "@supabase/supabase-js";

// --- Local cache for user email + confirmation
type CachedUser = { email: string | null; email_confirmed: boolean; ts: number };
const USER_CACHE_TTL_MS = 60_000;
const userCache = new Map<string, CachedUser>();

// --- Schema-aligned types
type Project = {
  id: string;
  owner: string | null;
  name: string;
  origin: string | null;
  share_token?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  // keep index signature to avoid TS noise with extra columns
  [key: string]: unknown;
};

type Membership = {
  project_id: string;
  user_id: string;
  role: "owner" | "editor" | "viewer" | null;
  created_at?: string | null;
};

// --- Helpers
function simpleNameFromUrl(u: URL) {
  const path = u.pathname.replace(/\/$/, "");
  return path && path !== "/" ? `${u.hostname}${path}` : u.hostname;
}

export default async function ProtectedPage() {
  const supabase = await createClient();

  // If you have getClaims working in your stack, keep it; otherwise use getUser()
  const { data: claimsData, error: claimsErr } = await supabase.auth.getClaims();
  if (claimsErr || !claimsData?.claims) {
    redirect("/auth/login");
  }

  // Resolve current user id (used for role chips and createProject)
  let currentUserId: string | undefined;
  try {
    const { data: userResp } = await supabase.auth.getUser();
    currentUserId = userResp?.user?.id ?? undefined;

    // NOTE: your schema's memberships has no "joined_at", so there's nothing to "mark as joined".
    // Leaving this block empty intentionally.
  } catch (e) {
    console.error("auth.getUser failed", e);
  }

async function createProject(formData: FormData) {
  "use server";

  const rawUrl = String(formData.get("url") ?? "").trim();
  if (!rawUrl) return;

  // Normalize URL
  let parsed: URL;
  try {
    parsed = new URL(/^https?:\/\//i.test(rawUrl) ? rawUrl : `https://${rawUrl}`);
  } catch {
    throw new Error("Invalid URL");
  }

  const s = await createClient();

  // Who is creating?
  const {
    data: { user },
    error: userErr,
  } = await s.auth.getUser();
  if (userErr || !user) throw new Error("Not authenticated");

  const creatorId = user.id;
  const candidate = simpleNameFromUrl(parsed);
  const name = candidate?.slice(0, 120) || "Project";

  // Pre-generate id; avoid .select()/RETURNING to not invoke projects.SELECT during INSERT
  const newId = crypto.randomUUID();

  // STEP 1: Insert project with user client (relies only on INSERT policy)
  const { error: insertErr } = await s.from("projects").insert({
    id: newId,
    owner: creatorId,
    name,
    origin: parsed.toString(),
  });
  if (insertErr) {
    console.error("Project insert failed:", insertErr);
    throw new Error(insertErr.message);
  }

  // STEP 3: Insert owner membership with ADMIN client (bypasses RLS; avoids recursion)
  const admin = createAdminClient();
  const { error: memErr } = await admin
    .from("memberships")
    .upsert(
      { project_id: newId, user_id: creatorId, role: "owner" as const },
      { onConflict: "user_id,project_id" }
    );
  if (memErr) {
    console.error("Owner membership upsert failed:", memErr);
    // Optional: clean up the project if membership write fails
    // await s.from("projects").delete().eq("id", newId);
    throw new Error(memErr.message);
  }

  revalidatePath("/protected");
}



  // --- Load visible projects
  const { data: projData, error: projError } = await supabase.from("projects").select("*");
  const projects: Project[] = (projData as Project[] | null) ?? [];

// --- Load memberships for those projects (ADMIN bypass for richer UI)
const projectIds = projects.map((p) => p.id).filter(Boolean);

type EnrichedMembership = Membership & {
  email: string | null;
  email_confirmed: boolean;
};

let membersByProject = new Map<string, EnrichedMembership[]>();

if (projectIds.length > 0) {
  const admin = createAdminClient();

  const { data: memData, error: memErr } = await admin
    .from("memberships")
    .select("*")
    .in("project_id", projectIds);

  if (memErr) {
    console.error("Failed to load memberships (admin)", memErr);
  }

  const basicMems: Membership[] = (memData as Membership[] | null) ?? [];

  // Fetch user emails once (cached)
  const uniqueUserIds = Array.from(new Set(basicMems.map((m) => m.user_id))).filter(Boolean);
  const userDetails = new Map<string, { email: string | null; email_confirmed: boolean }>();

  await Promise.all(
    uniqueUserIds.map(async (uid) => {
      const cached = userCache.get(uid);
      const now = Date.now();
      if (cached && now - cached.ts < USER_CACHE_TTL_MS) {
        userDetails.set(uid, { email: cached.email, email_confirmed: cached.email_confirmed });
        return;
      }
      try {
        const { data: userResp, error: userErr } = await admin.auth.admin.getUserById(uid);
        if (userErr) {
          console.error("getUserById error", uid, userErr);
          return;
        }
        const u = userResp?.user as User | null | undefined;
        const email = u?.email ?? null;
        const email_confirmed = Boolean(u?.email_confirmed_at ?? false);
        userDetails.set(uid, { email, email_confirmed });
        userCache.set(uid, { email, email_confirmed, ts: now });
      } catch (e) {
        console.error("getUserById threw", uid, e);
      }
    })
  );

  const enriched: EnrichedMembership[] = basicMems.map((m) => ({
    ...m,
    email: userDetails.get(m.user_id)?.email ?? null,
    email_confirmed: userDetails.get(m.user_id)?.email_confirmed ?? false,
  }));

  // ✅ No reduce: simple loop to build the map
  membersByProject = new Map<string, EnrichedMembership[]>();
  for (const m of enriched) {
    const arr = membersByProject.get(m.project_id) ?? [];
    arr.push(m);
    membersByProject.set(m.project_id, arr);
  }
}


  async function deleteProject(formData: FormData) {
    "use server";
    const id = formData.get("id");
    if (!id || typeof id !== "string") return;

    const s = await createClient();
    const { error: delError } = await s.from("projects").delete().eq("id", id);
    if (delError) {
      console.error("Failed to delete project", delError);
    }
    revalidatePath("/protected");
  }

  async function inviteMemberByEmail(formData: FormData) {
    "use server";
    const projectId = formData.get("project_id");
    const email = formData.get("email");
    const roleRaw = formData.get("role");
    if (typeof projectId !== "string" || typeof email !== "string" || !projectId || !email) return;

    const allowedRoles = new Set(["viewer", "editor", "owner"]);
    const role = typeof roleRaw === "string" && allowedRoles.has(roleRaw) ? (roleRaw as "viewer" | "editor" | "owner") : undefined;

    const admin = createAdminClient();

    // AuthZ: only owners can invite/manage
    const sForAuth = await createClient();
    const { data: meResp, error: meErr } = await sForAuth.auth.getUser();
    if (meErr || !meResp?.user?.id) throw new Error("Not authenticated");
    const myId = meResp.user.id;

    const { data: myMem, error: myMemErr } = await admin
      .from("memberships")
      .select("role")
      .eq("project_id", projectId)
      .eq("user_id", myId)
      .maybeSingle();
    if (myMemErr || !myMem || myMem.role !== "owner") throw new Error("Only owners can add members");

    // Find or invite user by email
    const { data: userList, error: listErr } = await admin.auth.admin.listUsers({ page: 1, perPage: 200 });
    if (listErr) console.error("Admin listUsers error", listErr);

    let userId: string | undefined = userList?.users?.find((u) => u.email?.toLowerCase() === email.toLowerCase())?.id;
    let userWasCreated = false;

    if (!userId) {
      const base = process.env.NEXT_PUBLIC_BASE_URL;
      const redirectTo = base ? `${base}/protected` : undefined;
      const { data: invite, error: inviteErr } = await admin.auth.admin.inviteUserByEmail(email, { redirectTo });
      if (inviteErr) {
        console.error("Admin invite error", inviteErr);
        return;
      }
      userId = invite.user?.id;
      userWasCreated = Boolean(userId);
    } else {
      try {
        const base = process.env.NEXT_PUBLIC_BASE_URL;
        const emailRedirectTo = base ? `${base}/protected` : undefined;
        const s = await createClient();
        await s.auth.signInWithOtp({ email, options: { emailRedirectTo } });
      } catch (e) {
        console.error("signInWithOtp error", e);
      }
    }

    if (!userId) {
      console.error("Could not resolve user id after invite");
      return;
    }

    // Upsert membership in YOUR memberships table
    const payload: Record<string, unknown> = { project_id: projectId, user_id: userId };
    if (role) payload.role = role;

    const { error: upsertError } = await admin
      .from("memberships")
      .upsert(payload, { onConflict: "user_id,project_id" });
    if (upsertError) {
      console.error("Failed to add member by email", upsertError);
      throw new Error(`Membership upsert failed: ${upsertError.message}`);
    }

    // Optional: generate action link
    let actionLink: string | undefined;
    try {
      const base = process.env.NEXT_PUBLIC_BASE_URL;
      const nextPath = "/protected";
      const redirectTo = base ? `${base}${nextPath}` : undefined;
      const linkType = (userWasCreated ? "invite" : "magiclink") as "invite" | "magiclink";
      const { data: linkData, error: linkErr } = await admin.auth.admin.generateLink({
        type: linkType,
        email,
        options: { redirectTo },
      });
      if (linkErr) {
        console.error("generateLink error", linkErr);
      } else if (linkData) {
        type GeneratedLink = { action_link?: string; properties?: { action_link?: string } };
        const ld = linkData as unknown as GeneratedLink;
        actionLink = ld.action_link ?? ld.properties?.action_link;
      }
    } catch (e) {
      console.error("generateLink threw", e);
    }

    revalidatePath("/protected");
    if (!actionLink) throw new Error("No action link returned from Supabase");
    return actionLink;
  }

  async function removeMember(formData: FormData) {
    "use server";
    const projectId = formData.get("project_id");
    const userId = formData.get("member_user_id");
    if (typeof projectId !== "string" || typeof userId !== "string" || !projectId || !userId) return;

    const admin = createAdminClient();

    // AuthZ: only owners can remove members
    const sForAuth = await createClient();
    const { data: meResp, error: meErr } = await sForAuth.auth.getUser();
    if (meErr || !meResp?.user?.id) throw new Error("Not authenticated");
    const myId = meResp.user.id;

    const { data: myMem, error: myMemErr } = await admin
      .from("memberships")
      .select("role")
      .eq("project_id", projectId)
      .eq("user_id", myId)
      .maybeSingle();
    if (myMemErr || !myMem || myMem.role !== "owner") throw new Error("Only owners can remove members");

    const { error: rmError } = await admin
      .from("memberships")
      .delete()
      .eq("project_id", projectId)
      .eq("user_id", userId);
    if (rmError) console.error("Failed to remove member", rmError);

    revalidatePath("/protected");
  }

  return (
    <div className="flex-1 w-full flex flex-col gap-12">
      <div className="w-full">
        <div className="bg-accent text-sm p-3 px-5 rounded-md text-foreground flex gap-3 items-center">
          <InfoIcon size="16" strokeWidth={2} />
          This is a protected page that you can only see as an authenticated user
        </div>
      </div>

      {/* Add by URL */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Add a project by URL</CardTitle>
          <CardDescription>Paste a webpage / repo / doc URL. We’ll store it in <code>projects.origin</code> and set you as owner.</CardDescription>
        </CardHeader>
        <CardContent>
          <form action={createProject} className="flex gap-2 items-center">
            <Input
              type="url"
              name="url"
              required
              placeholder="https://example.com/path"
              className="flex-1"
              autoComplete="off"
            />
            <Button type="submit" size="sm">
              <Plus className="w-4 h-4 mr-1" />
              Create
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2 items-start">
          <h2 className="font-bold text-2xl">Projects</h2>
          <p className="text-sm text-muted-foreground">
            Loaded from your Supabase table <code>projects</code>.
          </p>
        </div>

        {/* projects grid */}
        {projError ? (
          <div className="text-sm text-destructive border border-destructive/30 bg-destructive/5 rounded p-3">
            Failed to load projects: {projError.message}
          </div>
        ) : projects.length === 0 ? (
          <div className="text-sm text-muted-foreground">No projects found. Create one above.</div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p) => {
              const title = p.name || p.origin || p.id;
              const desc = p.origin || "";
              const mems = p.id ? (membersByProject.get(p.id) ?? []) : [];
              const myRole = currentUserId ? mems.find((m) => m.user_id === currentUserId)?.role ?? null : null;

              return (
                <Card key={p.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between gap-2">
                      <CardTitle className="text-base">{String(title)}</CardTitle>
                      {myRole && (
                        <span className="text-[10px] uppercase tracking-wide rounded bg-accent px-1.5 py-0.5">
                          {myRole}
                        </span>
                      )}
                    </div>
                    {desc && <CardDescription className="line-clamp-2">{String(desc)}</CardDescription>}
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    <div className="flex flex-col gap-1">
                      {p.created_at && <div>Created: {new Date(p.created_at).toLocaleString()}</div>}
                      <div>ID: {String(p.id)}</div>
                    </div>
                    {/* Owner-only membership management */}
                    {p.id && myRole === "owner" && (
                      <div className="mt-2">
                        <MembersDialog
                          projectId={p.id}
                          members={membersByProject.get(p.id) ?? []}
                          onInviteByEmail={inviteMemberByEmail}
                          onRemove={removeMember}
                        />
                      </div>
                    )}
                  </CardContent>
                  {p.id && (
                    <CardFooter className="justify-end gap-2 flex-wrap">
                      <form action={deleteProject}>
                        <input type="hidden" name="id" value={p.id} />
                        <Button type="submit" variant="destructive" size="sm">
                          Delete
                        </Button>
                      </form>
                    </CardFooter>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
